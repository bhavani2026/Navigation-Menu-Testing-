package tests;
import org.testng.annotations.Test;

public class SearchTest {
 @Test
 public void searchTest() {
   System.out.println("Search Test Passed");
 }
}
