
package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class NavigationMenuTest {

    @Test
    public void verifyNavigationMenu() {
        String homePage = "Home";
        Assert.assertEquals(homePage, "Home");
        System.out.println("Navigation Menu Test Passed");
    }
}
